# Warehouse Dashboard Monitoring System

## Installation Instructions

1. Upload this package to your server
2. Extract the archive
3. Run the installation script as root:
   ```bash
   sudo bash install.sh
   ```

## Files Included

- `api/` - Monitoring API endpoints
- `config/` - Configuration files
- `scripts/` - Monitoring scripts and utilities
- `monitoring.html` - Web dashboard
- `install.sh` - Installation script
- `MONITORING_SETUP_GUIDE.md` - Detailed setup guide

## Quick Test

After installation, test the monitoring system:

```bash
# Test monitoring API
php /var/www/market-mi.ru/api/monitoring.php

# Test uptime monitor
php /var/www/market-mi.ru/scripts/uptime_monitor.php

# Access dashboard
https://www.market-mi.ru/monitoring.html
```

## Setup Cron Jobs

```bash
bash /var/www/market-mi.ru/scripts/setup_monitoring_cron.sh
```

This will set up automated monitoring tasks.
