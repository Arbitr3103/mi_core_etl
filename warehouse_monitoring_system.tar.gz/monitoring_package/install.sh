#!/bin/bash

# Monitoring System Installation Script
# Run this script on the production server

set -e

INSTALL_PATH="/var/www/market-mi.ru"
LOG_PATH="/var/log/warehouse-dashboard"

echo "🚀 Installing Warehouse Dashboard Monitoring System..."

# Create log directory
echo "📁 Creating log directory..."
mkdir -p "$LOG_PATH"
chown www-data:www-data "$LOG_PATH"
chmod 755 "$LOG_PATH"

# Copy files to installation directory
echo "📋 Copying files..."
cp -r api/* "$INSTALL_PATH/api/"
cp -r config/* "$INSTALL_PATH/config/"
cp -r scripts/* "$INSTALL_PATH/scripts/"
cp -r tests/* "$INSTALL_PATH/tests/" 2>/dev/null || mkdir -p "$INSTALL_PATH/tests"
cp monitoring.html "$INSTALL_PATH/"
cp MONITORING_SETUP_GUIDE.md "$INSTALL_PATH/"
cp run_production_tests.php "$INSTALL_PATH/" 2>/dev/null || true

# Set permissions
echo "🔐 Setting permissions..."
chmod +x "$INSTALL_PATH/scripts"/*.sh
chmod +x "$INSTALL_PATH/scripts"/*.php
chmod 644 "$INSTALL_PATH/api"/monitoring*.php
chmod 644 "$INSTALL_PATH/config/monitoring.php"
chmod 644 "$INSTALL_PATH/monitoring.html"

# Set ownership
chown -R www-data:www-data "$INSTALL_PATH/api/"
chown -R www-data:www-data "$INSTALL_PATH/config/"
chown www-data:www-data "$INSTALL_PATH/monitoring.html"

echo "✅ Installation completed!"
echo ""
echo "📊 Access monitoring dashboard at:"
echo "   https://www.market-mi.ru/monitoring.html"
echo ""
echo "🔧 Test monitoring:"
echo "   php $INSTALL_PATH/api/monitoring.php"
echo ""
echo "⏰ Setup cron jobs:"
echo "   bash $INSTALL_PATH/scripts/setup_monitoring_cron.sh"
