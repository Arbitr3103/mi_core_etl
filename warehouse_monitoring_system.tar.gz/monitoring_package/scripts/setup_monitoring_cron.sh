#!/bin/bash

# Setup Monitoring Cron Jobs
# This script sets up automated monitoring for the warehouse dashboard

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
LOG_DIR="/var/log/warehouse-dashboard"
PHP_BIN=$(which php)

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}Setting up Warehouse Dashboard Monitoring...${NC}"

# Create log directory if it doesn't exist
if [ ! -d "$LOG_DIR" ]; then
    echo "Creating log directory: $LOG_DIR"
    sudo mkdir -p "$LOG_DIR"
    sudo chown www-data:www-data "$LOG_DIR"
    sudo chmod 755 "$LOG_DIR"
fi

# Create monitoring scripts directory
MONITORING_DIR="$PROJECT_ROOT/monitoring"
if [ ! -d "$MONITORING_DIR" ]; then
    mkdir -p "$MONITORING_DIR"
fi

# Create wrapper scripts for cron jobs
echo "Creating cron wrapper scripts..."

# Uptime monitor wrapper
cat > "$MONITORING_DIR/run_uptime_check.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")/.."
export LOG_PATH="/var/log/warehouse-dashboard"
php scripts/uptime_monitor.php >> "$LOG_PATH/uptime_cron.log" 2>&1
EOF

# Performance monitor wrapper
cat > "$MONITORING_DIR/run_performance_check.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")/.."
export LOG_PATH="/var/log/warehouse-dashboard"
php api/monitoring.php?action=health >> "$LOG_PATH/performance_cron.log" 2>&1
EOF

# Log rotation wrapper
cat > "$MONITORING_DIR/rotate_logs.sh" << 'EOF'
#!/bin/bash
LOG_DIR="/var/log/warehouse-dashboard"
RETENTION_DAYS=30

# Rotate and compress old logs
find "$LOG_DIR" -name "*.log" -type f -mtime +1 -exec gzip {} \;

# Remove old compressed logs
find "$LOG_DIR" -name "*.log.gz" -type f -mtime +$RETENTION_DAYS -delete

# Remove old JSON files (metrics, alerts, etc.)
find "$LOG_DIR" -name "*.json" -type f -mtime +$RETENTION_DAYS -delete

# Remove old status files
find "$LOG_DIR" -name "uptime_status.json" -type f -mtime +7 -delete
find "$LOG_DIR" -name "cooldown_*.txt" -type f -mtime +1 -delete
find "$LOG_DIR" -name "failures_*.json" -type f -mtime +1 -delete

echo "Log rotation completed at $(date)"
EOF

# Database health check wrapper
cat > "$MONITORING_DIR/check_database_health.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")/.."
export LOG_PATH="/var/log/warehouse-dashboard"

# Check database connectivity and performance
php -r "
require_once 'config/production.php';
try {
    \$pdo = new PDO(
        \"pgsql:host={\$_ENV['DB_HOST']};port={\$_ENV['DB_PORT']};dbname={\$_ENV['DB_NAME']}\",
        \$_ENV['DB_USER'],
        \$_ENV['DB_PASSWORD'],
        [PDO::ATTR_TIMEOUT => 10]
    );
    
    \$start = microtime(true);
    \$stmt = \$pdo->query('SELECT COUNT(*) FROM warehouse_sales_metrics');
    \$count = \$stmt->fetchColumn();
    \$time = round((microtime(true) - \$start) * 1000, 2);
    
    echo \"Database health check passed. Records: \$count, Query time: {$time}ms\n\";
    
    if (\$time > 5000) {
        echo \"WARNING: Slow database query detected\n\";
        exit(1);
    }
    
} catch (Exception \$e) {
    echo \"Database health check failed: \" . \$e->getMessage() . \"\n\";
    exit(1);
}
" >> "$LOG_PATH/database_health.log" 2>&1
EOF

# Make scripts executable
chmod +x "$MONITORING_DIR"/*.sh

echo -e "${GREEN}Created monitoring wrapper scripts${NC}"

# Create cron jobs
echo "Setting up cron jobs..."

# Create temporary cron file
TEMP_CRON=$(mktemp)

# Get existing cron jobs (excluding our monitoring jobs)
crontab -l 2>/dev/null | grep -v "warehouse-dashboard-monitoring" > "$TEMP_CRON" || true

# Add monitoring cron jobs
cat >> "$TEMP_CRON" << EOF

# Warehouse Dashboard Monitoring Jobs
# Check uptime every 5 minutes
*/5 * * * * $MONITORING_DIR/run_uptime_check.sh # warehouse-dashboard-monitoring

# Check performance every 15 minutes
*/15 * * * * $MONITORING_DIR/run_performance_check.sh # warehouse-dashboard-monitoring

# Check database health every 30 minutes
*/30 * * * * $MONITORING_DIR/check_database_health.sh # warehouse-dashboard-monitoring

# Rotate logs daily at 2 AM
0 2 * * * $MONITORING_DIR/rotate_logs.sh # warehouse-dashboard-monitoring

# Weekly system health report (Mondays at 9 AM)
0 9 * * 1 $MONITORING_DIR/generate_weekly_report.sh # warehouse-dashboard-monitoring

EOF

# Install new cron jobs
crontab "$TEMP_CRON"
rm "$TEMP_CRON"

echo -e "${GREEN}Cron jobs installed successfully${NC}"

# Create weekly report generator
cat > "$MONITORING_DIR/generate_weekly_report.sh" << 'EOF'
#!/bin/bash
cd "$(dirname "$0")/.."
export LOG_PATH="/var/log/warehouse-dashboard"

REPORT_FILE="$LOG_PATH/weekly_report_$(date +%Y-%m-%d).txt"

echo "Warehouse Dashboard Weekly Report - $(date)" > "$REPORT_FILE"
echo "================================================" >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

# Uptime statistics
echo "UPTIME STATISTICS (Last 7 days):" >> "$REPORT_FILE"
php scripts/uptime_monitor.php?action=stats&days=7 >> "$REPORT_FILE" 2>&1
echo "" >> "$REPORT_FILE"

# Alert statistics
echo "ALERT STATISTICS (Last 7 days):" >> "$REPORT_FILE"
php scripts/alert_manager.php?action=stats&days=7 >> "$REPORT_FILE" 2>&1
echo "" >> "$REPORT_FILE"

# Performance metrics
echo "PERFORMANCE METRICS (Last 7 days):" >> "$REPORT_FILE"
php api/monitoring.php?action=metrics&hours=168 >> "$REPORT_FILE" 2>&1
echo "" >> "$REPORT_FILE"

# Disk usage
echo "DISK USAGE:" >> "$REPORT_FILE"
df -h / >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

# Log file sizes
echo "LOG FILE SIZES:" >> "$REPORT_FILE"
du -sh "$LOG_PATH"/* 2>/dev/null | sort -hr >> "$REPORT_FILE"
echo "" >> "$REPORT_FILE"

echo "Report generated at $(date)" >> "$REPORT_FILE"

# Optionally email the report (if configured)
if [ -f "$LOG_PATH/email_reports.conf" ]; then
    source "$LOG_PATH/email_reports.conf"
    if [ ! -z "$REPORT_EMAIL" ]; then
        mail -s "Warehouse Dashboard Weekly Report" "$REPORT_EMAIL" < "$REPORT_FILE"
    fi
fi
EOF

chmod +x "$MONITORING_DIR/generate_weekly_report.sh"

# Create monitoring dashboard
echo "Creating monitoring dashboard..."

cat > "$PROJECT_ROOT/monitoring_dashboard.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warehouse Dashboard - Monitoring</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .status-indicator {
            display: inline-block;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 8px;
        }
        .status-operational { background-color: #28a745; }
        .status-warning { background-color: #ffc107; }
        .status-critical { background-color: #dc3545; }
        .status-degraded { background-color: #fd7e14; }
        .metric {
            display: flex;
            justify-content: space-between;
            margin: 10px 0;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .metric:last-child {
            border-bottom: none;
        }
        .refresh-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .refresh-btn:hover {
            background: #0056b3;
        }
        .alert-item {
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
            border-left: 4px solid;
        }
        .alert-critical { border-color: #dc3545; background: #f8d7da; }
        .alert-error { border-color: #fd7e14; background: #ffeaa7; }
        .alert-warning { border-color: #ffc107; background: #fff3cd; }
        .alert-info { border-color: #17a2b8; background: #d1ecf1; }
        .loading {
            text-align: center;
            color: #666;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Warehouse Dashboard Monitoring</h1>
            <p>Real-time monitoring and health status</p>
            <button class="refresh-btn" onclick="refreshAll()">Refresh All</button>
        </div>
        
        <div class="grid">
            <div class="card">
                <h3>System Health</h3>
                <div id="health-status" class="loading">Loading...</div>
            </div>
            
            <div class="card">
                <h3>Uptime Status</h3>
                <div id="uptime-status" class="loading">Loading...</div>
            </div>
            
            <div class="card">
                <h3>Performance Metrics</h3>
                <div id="performance-metrics" class="loading">Loading...</div>
            </div>
            
            <div class="card">
                <h3>Recent Alerts</h3>
                <div id="recent-alerts" class="loading">Loading...</div>
            </div>
        </div>
    </div>

    <script>
        async function fetchData(url) {
            try {
                const response = await fetch(url);
                return await response.json();
            } catch (error) {
                console.error('Fetch error:', error);
                return { error: error.message };
            }
        }

        function formatStatus(status) {
            const statusClass = `status-${status}`;
            return `<span class="${statusClass} status-indicator"></span>${status.toUpperCase()}`;
        }

        function formatTimestamp(timestamp) {
            return new Date(timestamp * 1000).toLocaleString();
        }

        async function loadHealthStatus() {
            const data = await fetchData('/api/monitoring.php?action=health');
            const container = document.getElementById('health-status');
            
            if (data.error) {
                container.innerHTML = `<div class="alert-error">Error: ${data.error}</div>`;
                return;
            }
            
            let html = `
                <div class="metric">
                    <span>Overall Status:</span>
                    <span>${formatStatus(data.status)}</span>
                </div>
                <div class="metric">
                    <span>Response Time:</span>
                    <span>${data.response_time_ms}ms</span>
                </div>
            `;
            
            for (const [check, result] of Object.entries(data.checks)) {
                html += `
                    <div class="metric">
                        <span>${check.replace('_', ' ').toUpperCase()}:</span>
                        <span>${formatStatus(result.status)}</span>
                    </div>
                `;
            }
            
            container.innerHTML = html;
        }

        async function loadUptimeStatus() {
            const data = await fetchData('/scripts/uptime_monitor.php?action=stats&days=1');
            const container = document.getElementById('uptime-status');
            
            if (data.error) {
                container.innerHTML = `<div class="alert-error">Error: ${data.error}</div>`;
                return;
            }
            
            const html = `
                <div class="metric">
                    <span>Uptime (24h):</span>
                    <span>${data.uptime_percentage}%</span>
                </div>
                <div class="metric">
                    <span>Total Checks:</span>
                    <span>${data.total_checks}</span>
                </div>
                <div class="metric">
                    <span>Successful:</span>
                    <span>${data.successful_checks}</span>
                </div>
                <div class="metric">
                    <span>Avg Response:</span>
                    <span>${data.avg_response_time_ms}ms</span>
                </div>
            `;
            
            container.innerHTML = html;
        }

        async function loadPerformanceMetrics() {
            const data = await fetchData('/api/monitoring.php?action=metrics&hours=24');
            const container = document.getElementById('performance-metrics');
            
            if (data.error) {
                container.innerHTML = `<div class="alert-error">Error: ${data.error}</div>`;
                return;
            }
            
            const html = `
                <div class="metric">
                    <span>Total Requests:</span>
                    <span>${data.total_requests}</span>
                </div>
                <div class="metric">
                    <span>Avg Response:</span>
                    <span>${data.avg_response_time_ms}ms</span>
                </div>
                <div class="metric">
                    <span>Error Rate:</span>
                    <span>${data.error_rate_percent}%</span>
                </div>
            `;
            
            container.innerHTML = html;
        }

        async function loadRecentAlerts() {
            const data = await fetchData('/scripts/alert_manager.php?action=list&hours=24');
            const container = document.getElementById('recent-alerts');
            
            if (data.error) {
                container.innerHTML = `<div class="alert-error">Error: ${data.error}</div>`;
                return;
            }
            
            if (data.length === 0) {
                container.innerHTML = '<div class="alert-info">No alerts in the last 24 hours</div>';
                return;
            }
            
            let html = '';
            data.slice(0, 5).forEach(alert => {
                html += `
                    <div class="alert-item alert-${alert.severity}">
                        <strong>${alert.type}</strong> - ${alert.message}
                        <br><small>${formatTimestamp(alert.timestamp)}</small>
                    </div>
                `;
            });
            
            container.innerHTML = html;
        }

        async function refreshAll() {
            await Promise.all([
                loadHealthStatus(),
                loadUptimeStatus(),
                loadPerformanceMetrics(),
                loadRecentAlerts()
            ]);
        }

        // Initial load
        refreshAll();

        // Auto-refresh every 30 seconds
        setInterval(refreshAll, 30000);
    </script>
</body>
</html>
EOF

echo -e "${GREEN}Created monitoring dashboard at monitoring_dashboard.html${NC}"

# Create configuration file template
cat > "$PROJECT_ROOT/config/alerts.json" << 'EOF'
{
    "enabled": true,
    "channels": {
        "log": {
            "enabled": true
        },
        "email": {
            "enabled": false,
            "recipients": []
        },
        "webhook": {
            "enabled": false,
            "url": ""
        }
    },
    "thresholds": {
        "response_time_ms": 3000,
        "error_rate_percent": 5.0,
        "uptime_percent": 99.0,
        "disk_usage_percent": 85.0,
        "memory_usage_percent": 85.0
    },
    "cooldown_minutes": 30,
    "escalation": {
        "enabled": false,
        "after_minutes": 60,
        "channels": ["email"]
    }
}
EOF

echo -e "${GREEN}Created alert configuration template${NC}"

# Test the monitoring setup
echo -e "${YELLOW}Testing monitoring setup...${NC}"

# Test uptime monitor
echo "Testing uptime monitor..."
if php "$SCRIPT_DIR/uptime_monitor.php" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Uptime monitor working${NC}"
else
    echo -e "${RED}✗ Uptime monitor failed${NC}"
fi

# Test alert manager
echo "Testing alert manager..."
if php "$SCRIPT_DIR/alert_manager.php?action=test" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Alert manager working${NC}"
else
    echo -e "${RED}✗ Alert manager failed${NC}"
fi

# Test monitoring API
echo "Testing monitoring API..."
if php "$PROJECT_ROOT/api/monitoring.php?action=health" > /dev/null 2>&1; then
    echo -e "${GREEN}✓ Monitoring API working${NC}"
else
    echo -e "${RED}✗ Monitoring API failed${NC}"
fi

echo ""
echo -e "${GREEN}Monitoring setup completed!${NC}"
echo ""
echo "Next steps:"
echo "1. Configure email alerts in config/alerts.json"
echo "2. Set up webhook notifications if needed"
echo "3. Access monitoring dashboard at: /monitoring_dashboard.html"
echo "4. Check logs in: $LOG_DIR"
echo ""
echo "Cron jobs installed:"
echo "- Uptime check: every 5 minutes"
echo "- Performance check: every 15 minutes"
echo "- Database health: every 30 minutes"
echo "- Log rotation: daily at 2 AM"
echo "- Weekly report: Mondays at 9 AM"
EOF

chmod +x "$SCRIPT_DIR/setup_monitoring_cron.sh"